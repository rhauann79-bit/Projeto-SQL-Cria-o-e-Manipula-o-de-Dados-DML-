# Projeto SQL – Criação e Manipulação de Dados (DML)

Este repositório contém scripts SQL completos para criação, inserção, consulta, atualização e exclusão de dados para um sistema de Loja Online.

## Estrutura

- 01_create_tables.sql
- 02_insert_data.sql
- 03_select_queries.sql
- 04_update_commands.sql
- 05_delete_commands.sql
- README.md

## Execução

Execute os arquivos na ordem acima em seu SGBD (MySQL Workbench ou PGAdmin).