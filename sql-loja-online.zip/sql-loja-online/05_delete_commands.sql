DELETE FROM itens_pedido
WHERE id_item = 3;

DELETE FROM produtos
WHERE preco < 50;

DELETE FROM pedidos
WHERE status = 'cancelado';