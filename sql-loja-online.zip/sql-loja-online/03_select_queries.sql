SELECT * 
FROM clientes
ORDER BY nome;

SELECT nome, preco
FROM produtos
WHERE preco > 500
ORDER BY preco DESC;

SELECT p.id_pedido, c.nome AS cliente, p.data_pedido, p.status
FROM pedidos p
JOIN clientes c ON c.id_cliente = p.id_cliente;

SELECT ip.id_item, pr.nome, ip.quantidade
FROM itens_pedido ip
JOIN produtos pr ON pr.id_produto = ip.id_produto
WHERE ip.id_pedido = 1;

SELECT c.nome, SUM(pr.preco * ip.quantidade) AS total_gasto
FROM clientes c
JOIN pedidos p ON p.id_cliente = c.id_cliente
JOIN itens_pedido ip ON ip.id_pedido = p.id_pedido
JOIN produtos pr ON pr.id_produto = ip.id_produto
GROUP BY c.nome
ORDER BY total_gasto DESC;