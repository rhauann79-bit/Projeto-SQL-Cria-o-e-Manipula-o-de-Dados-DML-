UPDATE clientes
SET email = 'ana.silva@gmail.com'
WHERE id_cliente = 1;

UPDATE produtos
SET preco = preco * 1.10
WHERE categoria = 'Acessórios';

UPDATE pedidos
SET status = 'finalizado'
WHERE id_pedido = 2;