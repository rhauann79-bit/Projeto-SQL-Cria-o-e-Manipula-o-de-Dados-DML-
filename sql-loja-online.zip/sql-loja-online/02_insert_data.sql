INSERT INTO clientes (nome, email, data_nascimento)
VALUES 
('Ana Silva', 'ana@gmail.com', '1990-04-15'),
('Bruno Costa', 'bruno@hotmail.com', '1985-11-30'),
('Carla Souza', 'carla@gmail.com', '1998-02-22');

INSERT INTO produtos (nome, preco, categoria) VALUES
('Notebook Lenovo', 3500.00, 'Informática'),
('Mouse Logitech', 80.00, 'Acessórios'),
('Cadeira Gamer XT', 1200.00, 'Móveis'),
('Teclado Mecânico Redragon', 250.00, 'Acessórios');

INSERT INTO pedidos (id_cliente, data_pedido, status) VALUES
(1, '2024-10-01', 'finalizado'),
(2, '2024-10-05', 'aberto'),
(1, '2024-11-02', 'aberto');

INSERT INTO itens_pedido (id_pedido, id_produto, quantidade) VALUES
(1, 1, 1),
(1, 2, 2),
(2, 4, 1),
(3, 3, 1);